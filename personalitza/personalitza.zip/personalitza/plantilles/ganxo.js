// Plantilla viva: on va el títol del ganxo. Variables: lloc = dalt · mig · baix.
window.composicio = function (escena, v, gsap) {
  const titol = escena.querySelector("#titol");
  const caixa = titol.firstElementChild;
  titol.classList.add(["dalt", "mig", "baix"].includes(v.lloc) ? v.lloc : "dalt");
  const tl = gsap.timeline({ paused: true });
  tl.set(titol, { opacity: 1 }, 0.25);
  tl.fromTo(caixa, { scale: 0.92, opacity: 0 }, { scale: 1, opacity: 1, duration: 8 / 30, ease: "expo.out" }, 0.25);
  tl.to(caixa, { opacity: 0, duration: 6 / 30, ease: "power2.in" }, 3.0);
  tl.set({}, {}, 4);
  return tl;
};
