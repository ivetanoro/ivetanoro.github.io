// Plantilla viva: com entren els subtítols, una paraula cada cop.
// La pàgina la dibuixa damunt del vídeo de la persona. Variables: entrada = cop · puja · karaoke · maquina.
// dades.paraules: [{text, inici, final}] en segons, del tros de vídeo.
window.composicio = function (escena, v, gsap, dades) {
  const P = Array.isArray(dades.paraules) ? dades.paraules : [];
  const F = 1 / 30;
  const tl = gsap.timeline({ paused: true });
  const subs = escena.querySelector("#subs");
  const fi = (i) => {
    const p = P[i], s = P[i + 1];
    return s && s.inici - p.final < 0.35 ? s.inici : p.final + 0.3;
  };
  if (v.entrada === "karaoke") {
    // Tota la frase alhora; la paraula que es diu, en blanc
    const frase = document.createElement("div");
    frase.id = "frase";
    const tall = Math.ceil(P.length / 2) - 1;
    const spans = P.map((p, i) => {
      const s = document.createElement("span");
      s.textContent = p.text;
      frase.append(s, i === tall ? document.createElement("br") : " ");
      return s;
    });
    subs.append(frase);
    if (P.length) {
      tl.set(frase, { opacity: 1 }, Math.max(0, P[0].inici - 0.05));
      P.forEach((p, i) => {
        tl.set(spans[i], { color: "#ffffff" }, p.inici);
        if (i < P.length - 1) tl.set(spans[i], { color: "rgba(255, 255, 255, 0.42)" }, P[i + 1].inici);
      });
      tl.set(frase, { opacity: 0 }, P[P.length - 1].final + 0.3);
    }
  } else {
    P.forEach((p, i) => {
      const el = document.createElement("div");
      el.className = "sub";
      if (v.entrada === "puja") {
        const masc = document.createElement("div");
        masc.className = "masc";
        masc.append(el);
        subs.append(masc);
        el.textContent = p.text;
        tl.set(el, { opacity: 1 }, p.inici);
        tl.fromTo(el, { yPercent: 110 }, { yPercent: 0, duration: 6 * F, ease: "expo.out" }, p.inici);
      } else if (v.entrada === "maquina") {
        subs.append(el);
        tl.set(el, { opacity: 1 }, p.inici);
        const lletres = [...p.text].map((c) => {
          const s = document.createElement("span");
          s.textContent = c;
          s.style.opacity = "0";
          el.append(s);
          return s;
        });
        const pas = Math.min(0.045, (p.final - p.inici) / lletres.length);
        lletres.forEach((s, k) => tl.set(s, { opacity: 1 }, p.inici + k * pas));
      } else {
        subs.append(el);
        el.textContent = p.text;
        tl.set(el, { opacity: 1 }, p.inici);
      }
      tl.set(el, { opacity: 0 }, fi(i));
    });
  }
  tl.set({}, {}, 4);
  return tl;
};
