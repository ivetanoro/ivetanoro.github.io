---
name: personalitza
description: Troba l'estil dels vídeos d'una persona, pas a pas, amb una pàgina de claude.ai on respon l'entrevista, puja les referències i el seu vídeo, i valora opcions vives (Sí, Potser o No). Fes-la servir quan algú vulgui trobar o definir l'estil dels seus vídeos (subtítols, títols, transicions, grafisme, sons), començar o continuar un estil, o digui «personalitza», «trobem el meu estil», «fem una ronda» o «fet» després d'acabar un pas.
---

# personalitza

Tot en català i amb paraules senzilles: la majoria de persones que la fan servir no són programadores. On diu «la persona», és qui t'ha demanat trobar el seu estil.

personalitza troba l'estil dels vídeos d'una persona. Tot passa en **una pàgina de claude.ai, per passos**: la persona hi escriu o dicta, hi puja fitxers i hi valora opcions, i quan acaba un pas prem **Fet, envia-ho** i et diu «fet». Tu llegeixes el que ha posat, li dius en poques línies què n'has entès, i li obres el pas següent. El xat és per parlar; la feina es fa a la pàgina.

| Pas | `pas` | Què hi fa la persona | Què hi fas tu |
|---|---|---|---|
| 1 | `entrevista` | Respon 8 preguntes (escrivint, o dictant amb el dictat del sistema) i hi adjunta el material que ja té | Llegeixes, repreguntes el que és vague, i escrius l'encàrrec en cinc línies |
| 2 | `referencies` | Puja de 3 a 5 referències (imatges, vídeos o enllaços) i diu què li agrada de cadascuna | Les mires de debò i li confirmes què hi veus |
| 3 | `video` | Puja un tros de 3 a 8 segons del seu vídeo i escriu què hi diu (o puja l'.srt o el .json) | Treus el temps de cada paraula |
| 4 | `rondes` | Valora les opcions: Sí, Potser o No, amb una nota | Fas les opcions vives, apuntes què queda fixat i fas la ronda següent |
| 5 | `estil` | Mira el seu estil i baixa l'ESTIL.md | El mantens al dia |

Si la persona fa servir [tallat](https://github.com/ivetanoro/tallat), l'editor de vídeo en català, al final en pots fer un `.estil.zip` que tallat obre (vegeu «L'estil en el format comú», a baix).

## Què cal

- **Les eines d'artifacts**: `Artifact` (publicar la pàgina, obrir-la, llegir-ne i pujar-hi fitxers) i `ArtifactData` (llegir i escriure la seva base de dades). **Abans de dir que no les tens, busca-les:** sovint estan carregades a mitges, i s'activen amb `ToolSearch` (`select:Artifact,ArtifactData`). Abans de la primera publicació, crida `Artifact` amb `action: "quickstart"` i, si hi ha la skill `artifact-capabilities`, carrega-la: la pàgina declara capacitats (`db`, `user`, `assets`, `downloads`). Només si després de buscar-les no hi són, digues-li que aquesta skill necessita Claude Code amb els artifacts de claude.ai (un compte de pagament, Pro o més), i para.
- **Res més per instal·lar.** Les opcions es dibuixen a la mateixa pàgina, damunt del vídeo de la persona. Si l'ordinador té ffmpeg o un transcriptor, et poden ajudar a treure el temps de les paraules (vegeu el pas 3), però no calen.

## On és cada cosa

- **Aquesta carpeta** (la de `SKILL.md`): les instruccions, `personalitza.html` (la pàgina) i `plantilles/` (exemples d'opcions vives).
- **La carpeta de l'estil**: `~/personalitza/<id>/`, una per estil. Hi van `artifact.txt` (l'enllaç), `pagina.html` (la còpia publicada), els fitxers que baixis per mirar-los i una còpia d'`ESTIL.md`.
- **La pàgina de claude.ai**: un artifact privat del compte de la persona. **Un artifact per a cada estil.** Si un dia en vol un altre (per exemple, per a un client), en publiques un de nou.

Abans de res, mira `~/personalitza/`. Si ja hi ha un estil, pregunta-li si vol continuar aquell o començar-ne un de nou. Per continuar-lo, llegeix-ne `artifact.txt` i ves a «Continuar».

## La base de dades

| Document | Qui l'escriu | Què hi ha |
|---|---|---|
| `laboratori/estat` | tu | `nom`, `proporcio` (`"9:16"`, `"16:9"`, `"1:1"` o `"4:5"`), `pas`, `encarrec` (fins a 5 línies), `creat` |
| `entrevista/preguntes` | tu (opcional) | `{"llista": [{clau, pregunta, ajuda}]}`. Si no hi és, la pàgina fa les 8 preguntes de sempre |
| `entrevista/respostes` | la pàgina | `{clau: text}` |
| `adjunts/<id>` | la pàgina | `{clau, asset, nom, tipus, mida}`: fitxers adjunts a una pregunta |
| `referencies/<id>` | la pàgina | `{asset, tipus}` o `{enllac}`, i `que_magrada`, `ordre` |
| `material/clip` | la pàgina | `{asset, text, paraules, subtitols}`: el tros de vídeo |
| `passos/<pas>` | la pàgina | `{enviat}`: quan ha premut «Fet, envia-ho» (`null` si l'ha tornat a obrir) |
| `rondes/rNN` | tu | la ronda (vegeu el pas 4) |
| `valoracions/rNN-<secció>-<opció>`, `preferides/rNN-<secció>`, `enviaments/rNN` | la pàgina | el que ha valorat |
| `apunts/<id>` | tu | Fixat, Descartat i Preguntes obertes |

Escriu-hi amb `ArtifactData` (`set`, `update`, `delete` o `batch`; passa sempre la `version` que has llegit com a `if_version`; la primera vegada que crees un document no n'hi ha, i no cal). **No escriguis mai en els documents de la pàgina**, tret de tornar a obrir un pas (`passos/<pas>` amb `{"enviat": null}`) quan calgui.

Per **mirar un fitxer** que hi ha pujat la persona (una referència, un adjunt, el vídeo): `Artifact` amb `action: "read"`, `url` de la pàgina i `path` = l'id del fitxer (l'`asset`). El baixa a l'ordinador i et diu on.

Per **portar-la a un pas**: posa `pas` a `laboratori/estat` i obre-li la pàgina amb `Artifact`, `action: "open"`. La pàgina hi va sola.

## Començar un estil

1. Pregunta-li quin nom li vol posar («Reels de cuina», «El meu canal»…). Si no en té cap, proposa'n un de curt. L'`id` és el nom en minúscules, sense accents i amb guions.
2. Crea `~/personalitza/<id>/` i copia-hi `personalitza.html` com a `pagina.html`. A la còpia, canvia el `<title>` pel nom de l'estil.
3. Publica-la amb `Artifact`: `file_path` = aquesta `pagina.html`, `icon`: `"video"`, `description`: «El laboratori d'estil de <nom>, pas a pas.», i aquestes capacitats:
   ```json
   {"db": {"rules": [{"path": "", "read": "view", "write": "admin"}]}, "user": {}, "assets": {}, "downloads": true}
   ```
   Així, només la persona (i tu, en nom seu) hi pot escriure, i ningú més hi veu res si ella no la comparteix.
4. Desa l'enllaç a `artifact.txt`.
5. Escriu el laboratori (`ArtifactData`, `set`, `laboratori/estat`):
   ```json
   {"nom": "Reels de cuina", "proporcio": "9:16", "pas": "entrevista", "encarrec": [], "creat": "AAAA-MM-DD"}
   ```
6. Obre-li la pàgina i digues-li, en dues línies: «Aquesta és la teva pàgina, privada. Respon les preguntes com vulguis, escrivint o amb el dictat del teu ordinador o del mòbil, i quan acabis prem “Fet, envia-ho” i digues-me “fet”.»

## Continuar

Llegeix `laboratori/estat` i els `passos`. Si el pas d'ara ja està enviat i encara no l'has llegit, fes el que diu el seu «Quan diu “fet”». Si no, obre-li la pàgina i recorda-li què li toca.

## Pas 1 · L'entrevista

La pàgina fa aquestes preguntes, amb exemples en gris a sota (no les facis tu al xat):

| Clau | Pregunta |
|---|---|
| `per_a_que` | Per a què és aquest estil? |
| `format` | On es veurà, i en quin format? |
| `public` | A quin públic et dirigeixes? |
| `mai` | Hi ha alguna cosa que tinguis clara que no t'agrada? |
| `ja_tens` | Tens algun material ja preparat que sempre facis servir? (amb el botó «Adjunta fitxers») |
| `moviment` | Com vols que sigui el moviment? |
| `so` | Com vols que soni? |
| `primer` | Per on t'agrada començar? |

**Quan diu «fet»:**
1. Llegeix `entrevista/respostes` i els `adjunts`. Baixa i mira els adjunts (lletres, logo, guia de marca).
2. **Format:** ha de quedar clara la proporció. Si diu «reels» o «TikTok», és vertical 9:16. Desa-la a `proporcio`.
3. **Si alguna resposta és vaga** («modern», «que quedi bé») o és buida, **no la desis com a bona**: afegeix-hi una pregunta nova a la pàgina. Escriu `entrevista/preguntes` amb `llista` = les 8 de la taula (amb les mateixes claus) **més** les noves al final (`{"clau": "public_2", "pregunta": "Quan dius «modern», què vols dir? Tens algun exemple?", "ajuda": "…"}`), torna a obrir el pas (`passos/entrevista` amb `{"enviat": null}`), obre-li la pàgina i digues-li què li has preguntat.
4. **Si té marca** (`ja_tens` o els adjunts): si t'ho permet, busca-la també a l'ordinador (guies, documents de disseny) i fes-ne un resum curt per confirmar que és la versió bona. Busca **contradiccions** entre la guia, el que fa a la pràctica i el que ha respost, i pregunta-les al xat, una per una.
5. **L'encàrrec:** escriu-li al xat el resum en **cinc línies** com a molt (per a què és, com s'ha de veure, com s'ha de moure i sonar, què no vol mai i per on començareu) i pregunta-li si li va bé. Quan digui que sí, desa'l a `encarrec`.
6. Posa `pas` a `referencies`, obre-li la pàgina i digues-li què ha de fer ara.

**Dictar:** la pàgina no té micròfon propi, perquè el dictat de claude.ai encara no entén el català. Si la persona vol dictar, recorda-li el dictat del sistema, que escriu a la caixa on té el cursor: al Mac, dues vegades la tecla Fn (o la del micròfon); a Windows, Windows + H; al mòbil, el micròfon del teclat.

No proposis opcions durant l'entrevista: primer s'escolta. Construeix només a partir del que digui i de les seves referències, mai de l'estil d'una altra persona.

## Pas 2 · Les referències

**Quan diu «fet»:**
1. Llegeix les `referencies`. L'ideal és de 3 a 5.
   - **Si en té menys de 3**, pregunta-li una sola vegada si en vol afegir (també valen enllaços d'Instagram o de TikTok, o una captura). Si diu que sí, torna a obrir el pas.
   - **Si no en té o no en vol posar més**, no l'encallis: continua amb les que hi hagi, o sense cap. L'estil sortirà de l'entrevista i de les rondes, i digues-li que les primeres rondes seran més obertes.
2. **Mira-les de debò.** Les imatges i els vídeos, baixa'ls i mira'ls (dels vídeos, treu-ne uns quants fotogrames si tens ffmpeg). Els enllaços, obre'ls amb un navegador si en tens, sense iniciar sessió; si no s'obren, demana-li una captura.
3. De cada una, digues-li al xat en una frase què hi veus (lletra, color, com es mou, ritme) i si és el que diu que li agrada. Si no ho és, aclareix-ho amb ella.
4. Posa `pas` a `video`, obre-li la pàgina i digues-li què ha de fer ara.

## Pas 3 · El teu vídeo

**Quan diu «fet»:**
1. Llegeix `material/clip`. Ha de ser un tros de 3 a 8 segons, a càmera. Baixa'l i mira'l (si tens ffmpeg, la durada amb `ffprobe` i un parell de fotogrames).
   - **Si no n'ha pujat cap**, no l'encallis: digues-li que les opcions es veuran damunt d'un fons neutre i que el pot pujar quan vulgui (la pàgina el farà servir tan bon punt el pugi). Per als subtítols, fes servir una frase curta de la seva entrevista, o «Avui t'ensenyo com ho faig», amb el temps repartit (0,3 s per paraula) a `paraules`. Ves al punt 3.
2. **El temps de cada paraula** (els subtítols de les opcions el necessiten):
   - Si `material/clip.paraules` ja hi és (ha pujat un .srt o un .json), fes-lo servir. Si `subtitols.aproximat` és `true`, el temps de cada paraula és calculat a partir de les línies: mira si quadra amb el vídeo.
   - Si no, i a l'ordinador hi ha un transcriptor (whisper, el de tallat…), fes-lo servir amb el vídeo baixat, amb el seu permís.
   - Si no, reparteix el text de `material/clip.text` entre l'inici i el final de la veu (amb ffmpeg `silencedetect`, si en tens) i digues-li que és aproximat. També li pots demanar que pugi l'.srt.
   - Les paraules van a cada ronda, a `paraules`: `[{"text": "Avui", "inici": 0.30, "final": 0.60}, …]`, en segons.
3. Posa `pas` a `rondes`, fes la primera ronda i obre-li la pàgina.

## Pas 4 · Les rondes

Una ronda és un grup d'opcions perquè les valori. Les opcions són **vives**: no es renderitzen. Tu escrius cada secció com una plantilla (HTML, CSS i JavaScript), i la pàgina la dibuixa al moment damunt del vídeo de la persona, seguint el temps del vídeo.

### Preparar-ne una

1. **Rellegeix què ja està decidit:** els `apunts` (Fixat, Descartat i Preguntes obertes), les valoracions de l'última ronda i la seva marca. Si el que anaves a proposar ja està decidit, digues-l'hi i proposa una ronda sobre el que encara està obert.
2. **Les opcions:** de 3 a 6 per secció i d'1 a 4 seccions per ronda. **Entre les opcions d'una secció, canvia una sola cosa** (on va, o la mida, o com entra), amb el mateix text i el mateix tros, perquè la comparació sigui justa. A la primera ronda, comença per on ha dit a `primer`.
3. **La plantilla de cada secció** (mira els exemples de `plantilles/`):
   - `html`: el que es posa dins de l'escena. L'escena fa 1080 × 1920 px en 9:16 (1920 × 1080 en 16:9, 1080 × 1080 en 1:1, 1080 × 1350 en 4:5), amb el fons transparent: a sota hi ha el vídeo.
   - `css`: els estils, en px d'aquesta escena. Lletres: les seves o de Google Fonts, amb `@import url("https://fonts.googleapis.com/css2?family=…&display=swap");` al principi.
   - `js`: ha de definir `window.composicio = function (escena, v, gsap, dades) { … return tl; }`. `escena` és el contenidor; `v`, les variables de l'opció; `gsap`, GSAP 3.12.5; `dades.paraules`, el temps de cada paraula, i `dades.text`, el que diu. Ha de tornar una línia de temps de GSAP en pausa (`gsap.timeline({ paused: true })`) en segons del vídeo. La pàgina la porta al segon que toca a cada moment, també enrere quan el vídeo torna a començar: **res de `setTimeout`, `requestAnimationFrame` ni rellotges propis**, tot dins de la línia de temps.
   - Corre en un marc aïllat, sense accés a res més: si falla, la targeta diu «Aquesta opció no s'ha pogut dibuixar».
4. **Escriu la ronda:** `ArtifactData` `set`, `rondes/rNN` (`r01`, `r02`…). El més còmode és escriure el JSON en un fitxer i passar-lo amb `file_path`:
   ```json
   {
     "numero": 1,
     "titol": "Subtítols: com entren",
     "intro": "Quatre maneres d'entrar la mateixa paraula, sobre el teu tros.",
     "canvis": ["El que ha canviat des de l'última ronda, una línia per cosa"],
     "paraules": [{"text": "Avui", "inici": 0.30, "final": 0.60}],
     "seccions": [
       {"id": "entrada", "nom": "Com entren", "us": "Què es compara en aquesta secció",
        "viva": {"html": "<div id=\"subs\"></div>", "css": "…", "js": "window.composicio = function (escena, v, gsap, dades) { … };"},
        "opcions": [
          {"id": "a", "etiqueta": "De cop", "descripcio": "Què té de diferent", "variables": {"entrada": "cop"}}
        ]}
     ],
     "fixat": [{"etiqueta": "…", "descripcio": "…", "viva": {"html": "…", "css": "…", "js": "…"}, "variables": {}}],
     "creada": "AAAA-MM-DD"
   }
   ```
   Els `id` de les seccions i de les opcions: curts, en minúscules, sense espais ni accents, i sense repetir. A `fixat`, el que ja està decidit, perquè ho tingui tot en un lloc (pot ser buit). Cada document ha de fer menys de 256 KB.
   - **Sons:** una opció de so pot ser un fitxer: puja'l en `.m4a` (vegeu «Pujar fitxers») i posa `"previa": "<id>", "tipus": "so"` en lloc de la plantilla.
5. **Obre-li la pàgina** i digues-li dues coses: **que se'n pot quedar tantes com vulgui** (cada secció ensenya maneres de fer el mateix moment, però el seu estil en pot tenir unes quantes), i que quan acabi, premi **Envia la valoració** i et digui «fet».

### Quan diu «fet»

1. **Llegeix el que ha dit** (`ArtifactData` `query`):
   - `valoracions` amb `["ronda", "==", N]`: cada document és una opció, amb `veredicte` (`guarda` = Sí, `potser` = Potser, `fora` = No), `abast` (si és No: `sempre` o `aqui`) i `nota`. Les notes poden dur botons ràpids separats per «;».
   - `preferides` amb `["ronda", "==", N]`: la preferida de cada secció.
   - `enviaments/rNN`: la nota general i si l'ha enviada. Si no l'ha enviada, pregunta-li si ja ha acabat.
2. **Explica-li en poques línies** què s'ha quedat, què ha tret, quina és la preferida de cada secció, i si hi veus cap patró a les notes.
3. **Abans d'apuntar res:**
   - Si a cada secció només n'hi ha un Sí i la resta són No, pregunta-li si ho ha entès així (se'n pot quedar unes quantes).
   - Si hi ha un **No sense abast**, pregunta-li si és per sempre o només aquí. El que va a Descartat educa tot l'estil i no torna a sortir mai; el que és només d'aquí, no.
   - Si un No no té nota, pregunta-li per què. Sense perquè, no es pot apuntar a Descartat.
   - El que no ha valorat no és ni sí ni no: no ho apuntis.
4. **Apunta-ho** a `apunts` (un document per cosa, amb `batch` si en són unes quantes; ids `a001`, `a002`…):
   ```json
   {"tipus": "fixat", "text": "…", "per_que": "…", "ronda": 1, "creat": "AAAA-MM-DDTHH:MM"}
   ```
   - `fixat`: el que s'ha quedat, **amb prou detall perquè algú altre ho pugui reproduir** (lletra, mida, color, posició, com entra, quant dura). La preferida, primer.
   - `descartat`: el que ha tret per sempre, **sempre amb el `per_que`**.
   - `pregunta`: el que queda obert, i els No «només aquí» (amb el context).
   - Si una línia ja no val, esborra aquell document.
5. **Torna a escriure `ESTIL.md`** a la carpeta de l'estil, amb el mateix que la pestanya «El teu estil» de la pàgina.
6. **Fes la ronda següent:** arregla cada Potser com diu la nota, porta més lluny el que s'ha quedat (la preferida pesa més), i no tornis a portar mai el que ha descartat si no t'ho demana. Si no ha deixat cap nota, digues-li que les notes fan millor la ronda següent.

Si vol canviar una valoració d'una ronda ja enviada, pot prémer **Torna a obrir**.

## Pas 5 · El teu estil

Quan una part de l'estil està prou fixada (o quan ella ho digui), posa `pas` a `estil` i obre-li la pàgina: hi veurà l'encàrrec, Fixat, Descartat i Preguntes obertes, i podrà baixar l'ESTIL.md. Poden continuar fent rondes quan vulgui: torna `pas` a `rondes`.

## Pujar fitxers

Normalment els puja la persona des de la pàgina. Si en necessites pujar tu (un so, una imatge per a una plantilla): `Artifact`, `url` = l'enllaç d'`artifact.txt`, `asset: true` i `file_paths` (fins a 25 per crida, de fins a 15 MB). La resposta dona l'`id` de cada fitxer: és el que va a la base de dades. Les plantilles, en canvi, millor que no depenguin de fitxers pujats: dibuixa-ho amb HTML i CSS (formes, lletres, colors), que és el que sempre es veu.

**L'espai té un límit.** Si una pujada diu que és ple, proposa-li esborrar fitxers que ja no calguin (`Artifact`, `action: "delete"`, `url` i `path` = l'id). Només amb el seu sí.

## Privacitat

- La pàgina i els fitxers són al compte de claude.ai de la persona, en un artifact privat. Només els veu qui ella convidi.
- El que baixes per mirar-ho es queda a la seva carpeta, a l'ordinador.
- Si vol esborrar-ho tot: `Artifact` `action: "delete"` amb l'enllaç (no es pot desfer: confirma-ho abans) i, si vol, la carpeta `~/personalitza/<id>/`.

## Si té tallat

Si existeix `~/.tallat/`, la persona fa servir tallat. Pots fer servir el seu ffmpeg (`~/.tallat/eines/bin/ffmpeg`) i el seu transcriptor per al temps de les paraules, i, quan una part de l'estil està fixada, proposar-li fer-ne un `.estil.zip` per obrir-lo a tallat.

## L'estil en el format comú

És el mateix format de tallat i matcha (`format: "estil/1"`). Quan ella ho vulgui, a `~/personalitza/<id>/estil/`:
- `estil.json`: `{"format": "estil/1", "nom": "…", "quadre": {"w": 1080, "h": 1920, "fps": 30}, "marca": {…}, "subtitols": {…}, "titol": {…}}`, només amb el que estigui **fixat** i es pugui dir amb un número, un color (`#RRGGBB`) o una de les opcions de tallat. Les mides són fraccions del quadre (de 0 a 1), mai píxels. Si dubtes d'una clau, deixa-la fora: tallat hi posarà la neutra.
- `NOTES.md`: una còpia d'`ESTIL.md`.
- Si fa servir lletres seves o gratuïtes, a `fonts/` amb el nom «Família__700.ttf» (o «__var» si és variable, «-cursiva» per a la cursiva).
Després, fes-ne un zip amb aquests fitxers a l'arrel (`<nom>.estil.zip`) i digues-li que a tallat s'obre amb Estil › Importa.

---

personalitza: Copyright © 2026 Ivet Anoro, tots els drets reservats (fitxer `LICENSE`). És gratis per fer-la servir als teus vídeos; no es pot repartir, vendre ni posar dins d'una altra eina. L'estil que hi facis és teu.
